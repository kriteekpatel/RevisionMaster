# Revision Master — Android App

This project wraps the existing Revision Master UI in a native Android application. It does **not** open as a Chrome/PWA app.

## Build APK on GitHub (no PC required)
1. Create a GitHub repository.
2. Upload this whole project.
3. Open **Actions → Build Android APK → Run workflow**.
4. When it finishes, open the workflow run and download the `RevisionMaster-debug-apk` artifact.
5. Extract the ZIP and install `app-debug.apk` on Android.

## Important
The app is standalone and stores the existing local data in its WebView storage. The existing Firebase web Google-login code may require a native OAuth configuration because Android WebView is not the same origin as the deployed Netlify site. Local/offline tracking works without that configuration.
